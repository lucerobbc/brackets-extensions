define(function (require, exports, module) {
    'use strict';

    module.exports = {
        root: true,
        de: true,
        es: true,
        fa: true,
        fr: true,
        it: true,
        ja: true,
        pl: true,
        'pt-br': true,
        ro: true,
        'zh-cn': true,
        ru: true
    };
});
